// Program to check if number is Magic number in JAVA
import java.util.*;
public class MagicNumberCheck
{
    public static void main(String args[])
    {
        Scanner ob=new Scanner(System.in);
        System.out.println("Enter the number to be checked.");
        int n=ob.nextInt();
        int sum=0,num=n;
        while(num>9)
        {
            sum=num;int s=0; ///breakpoint///
            while(sum!=0) /// it should be != instead of ==
            {
                s=s+(sum%10); /// It should be addition(+) instead of multiplication(*) and also modulus(%) instead of division(/). ///breakpoint///
                sum=sum/10; /// It should be division(/) instead of modulus(/). ///breakpoint///
            }
            num=s; ///breakpoint///
        }
        if(num==1)
        {
            System.out.println(n+" is a Magic Number.");
        }
        else
        {
            System.out.println(n+" is not a Magic Number.");
        }
    }
}

/*
Input: Enter the number to be checked 119
Output 119 is not a Magic Number.
Input: Enter the number to be checked 199
Output 199 is a Magic Number.
*/
