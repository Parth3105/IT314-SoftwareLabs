//Armstrong Number
public class Armstrong {
    public static void main(String args[]) {
        int num = Integer.parseInt(args[0]);
        int n = num; //use to check at last time
        int check = 0, remainder;
        while (n > 0) {
            remainder = n % 10; /// here it should be %. ///breakpoint///
            check = check + (int) Math.pow(remainder, 3);
            n = n / 10; /// here it should be /. ///breakpoint///
        }
        if (check == num)
            System.out.println(num + " is an Armstrong Number");
        else
            System.out.println(num + " is not an Armstrong Number");
    }
}
//    Input: 153
//    Output: 153 is an armstrong Number.